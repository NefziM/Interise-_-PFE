import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styles from '../dashboard.module.css';
import { useParams } from 'react-router-dom';

interface Product {
  Ref: string;
  Designation: string;
  Price: string;
  Stock: string;
  Image: string;
  Brand: string;
  Company: string;
  DiscountAmount: string;
  Description: string;
  BrandImage: string;
  Link: string;
  DateScrapping: Date;
  DateAjout?: Date;
  AncienPrix?: string;
  DateModification?: Date;
  supprime?: number;
  Category: string;
  Subcategory: string;
}

const ProductDetails: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();

  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    const fetchProductDetails = async () => {
        const url = `http://localhost:5000/api/products-by-reference/${productId}`;
        console.log("Fetching URL:", url);  // Afficher l'URL dans la console
        try {
            const response = await axios.get(url);
            console.log('API Response:', response.data); // Affichez les données reçues
            if (response.data && response.data.length > 0) {
                const productData = response.data[0];
                if (productData.DateScrapping) {
                    productData.DateScrapping = new Date(productData.DateScrapping);
                }
                setProduct(productData);
            } else {
                console.log("No data received or data format is incorrect");
                setProduct(null);
            }
        } catch (error) {
            console.error('Error fetching product details:', error);
            setProduct(null);
        }
    };

    fetchProductDetails();
}, [productId]);


return (
  <div className={styles.productDetails}>
    {product ? (
      <div className={styles.productContainer}>
        <div className={styles.productImage}>
          <img src={product.Image} alt={product.Designation} style={{ maxWidth: '400px', maxHeight: '500px' }} />
        </div>
        <div className={styles.productInfo}>
          <p className={styles.categoryInfo}>
            {product.Category} / {product.Subcategory}
          </p>
          <h2>{product.Designation}</h2>
          <p style={{ color: 'green', fontWeight: 'bold' }}> {product.Price}</p>
          <p> {product.Description}</p>
          <p style={{ color: product.Stock === "0" ? 'red' : 'green' }}>
             {product.Stock === "0" ? "Épuisé" : "En stock"}
          </p>
          <div style={{ marginTop: '20px' }}>
            <img src={product.BrandImage} alt={product.Brand} style={{ maxWidth: '100px' }} />
          </div>
          <p style={{ color: 'darkred' }}><b>{product.Company}</b></p>
          <a href={product.Link} target="_blank" rel="noopener noreferrer">Voir sur le site</a>
        </div>
      </div>
    ) : (
      <p>Chargement des détails du produit...</p>
    )}
  </div>
);



};

export default ProductDetails;
