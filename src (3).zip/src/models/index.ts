//src/models/index.ts
export { default as ProductModel } from "./product";
