import React, { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import styles from '../dashboard.module.css';
import { Input } from '@components';
import { DashboardComponents } from '@components';

interface Product {
  Ref: string;
  Designation: string;
  Price: string;
  Stock: string;
  Image: string;
  Brand: string;
  Company: string;
  Link: string;
}

const Update: React.FC = () => {
  const [search, setSearch] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(true);
  const date = new Date();
  date.setDate(date.getDate() - 1);
  const formattedDate = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
  const [fetched, setFetched] = useState<number>(0);
  const availableProducts = products.filter((product: Product) => product.Stock === 'En stock');
  const unavailableProducts = products.filter((product: Product) => product.Stock === 'Sur commande');

  // Copie des produits initiaux
  const [initialProducts, setInitialProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetchProducts();
    setFetched(50);
  }, [page, pageSize]);

  const fetchProducts = useCallback(() => {
    setLoadingProducts(true);

    axios
      .get('http://localhost:5000/api/products', {
        params: {
          page,
          pageSize,
        },
      })
      .then((response) => {
        const data: Product[] = response.data;

        console.log('All products:', data);

        // Remplacer la liste existante par la nouvelle liste de produits
        setProducts(data);
        
        // Sauvegarde des produits initiaux
        setInitialProducts(data);
        setLoadingProducts(false);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        setLoadingProducts(false);
      });
  }, [page, pageSize]);


  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = event.target;
      setSearch(value);
      if (value === "") {
        setFetched(50);
        // Réinitialiser les produits avec les produits initiaux
        setProducts(initialProducts);
      } else {
        const filteredProducts = initialProducts.filter(
          (product: Product) =>
            (product.Ref.toString().toLowerCase().includes(value.toLowerCase()) ||
            product.Designation.toLowerCase().includes(value.toLowerCase()) ||
            product.Stock.toLowerCase().includes(value.toLowerCase()) ||
            product.Company.toLowerCase().includes(value.toLowerCase()) ||
            product.Brand.toLowerCase().includes(value.toLowerCase())) // Ajouter cette condition pour filtrer par nom de société
        );
        setProducts(filteredProducts);
      }
    },
    [initialProducts]
  );
  
  const __handleLoadMore = () => {
    if (products.length > fetched) {
      const newFetched = fetched + 50;
      setFetched(newFetched);
    }
  };

  return (
    <div className={styles.dashboard_content}>
      <div className={styles.dashboard_content_container}>
        <div className={styles.dashboard_content_header}>
          <h2>Produits mis à jour</h2>
          <Input
            type="text"
            value={search}
            label="Search.."
            onChange={(e) => handleSearch(e)}
          />
        </div>

        <div className={styles.dashboard_content_cards}>
          <DashboardComponents.StatCard
            title="Tous Les Produits"
            value={products.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Produits Disponibles"
            value={availableProducts.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Produits Épuisés"
            value={unavailableProducts.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Nouveaux Produits"
            value={0}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Produits mise à jour"
            value={0}
            icon="/icons/product.svg"
          />
        </div>

        <table>
          <thead>
        
              <th>Image</th>
              <th>Ref</th>
              <th>Designation</th>
              <th>Marque</th>
              <th>Disponibilité</th>
              <th>Ancien Prix</th>
              <th>Date Ancien Prix</th>
              <th>Prix</th>
              <th>Entreprise</th>
              <th>Lien</th>
 
          </thead>


        </table>

        {products.length === 0 ? (
          <p style={{ textAlign: "center" }}>Aucun produit trouvé</p>
        ) : null}

        {products.length > fetched ? (
          <span
            className={styles.handle_more_button}
            onClick={__handleLoadMore}
          >
           Charger plus
          </span>
        ) : null}
      </div>
    </div>
  );
};

export default Update;
