import { CompetitorRo } from "@models";

export const competitors: CompetitorRo[] = [
  {
    id: "1",
    name: "Tunisianet",
    link: "https://www.tunisianet.com.tn",
    image: "/images/competitors/Tunisianet.jpg",
  },
];
