import React, { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import styles from '../dashboard.module.css';
import { Input } from '@components';
import { DashboardComponents } from '@components';

interface Product {
  Image: string;
  Ref: string;
  Designation: string;
  Brand: string;
  Stock: string;
  Price: string;
  Link: string;
}

const Products: React.FC = () => {
  const [search, setSearch] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(true);
  const date = new Date();
  date.setDate(date.getDate() - 1);
  const formattedDate = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
  const [fetched, setFetched] = useState<number>(0);
  const availableProducts = products.filter((product: Product) => product.Stock === 'En stock');
  const unavailableProducts = products.filter((product: Product) => product.Stock === 'Sur commande');

  
  useEffect(() => {
    fetchProducts();
    setFetched(50);
  }, [page, pageSize]);

  const fetchProducts = useCallback(() => {
    setLoadingProducts(true);

    axios
      .get('http://localhost:5000/api/products', {
        params: {
          page,
          pageSize,
         
        },
      })
      .then((response) => {
        const data: Product[] = response.data;

        console.log('All products:', data);

        setProducts((prevProducts) => [...prevProducts, ...data]);
        setLoadingProducts(false);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        setLoadingProducts(false);
      });
  }, [page, pageSize]);

  const handleSearch = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = event.target;
      setSearch(value);
      if (value === "") {
        setFetched(50);
        setProducts(products);
      } else {
        const filteredProducts = products.filter(
          (product: Product) =>
            product.Ref.toString()
              .toLowerCase()
              .includes(value.toLowerCase()) ||
            product.Designation.toLowerCase().includes(value.toLowerCase())
        );
        setProducts(filteredProducts);
      }
    },
    []
  );
  const __handleLoadMore = () => {
    if (products.length > fetched) {
      const newFetched = fetched + 50;
      setFetched(newFetched);
    }
  };

  return (
    <div className={styles.dashboard_content}>
      <div className={styles.dashboard_content_container}>
        <div className={styles.dashboard_content_header}>
          <h2>Produits</h2>
          <Input
            type="text"
            value={search}
            label="Search.."
            onChange={(e) => handleSearch(e)}
          />
        </div>

        <div className={styles.dashboard_content_cards}>
          <DashboardComponents.StatCard
            title="Tous Les Produits"
            value={products.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Produits Disponibles"
            value={availableProducts.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Produits Épuisés"
            value={unavailableProducts.length}
            icon="/icons/product.svg"
          />
          <DashboardComponents.StatCard
            title="Nouveaux Produits"
            value={0}
            icon="/icons/product.svg"
          />
        </div>

        <table>
          <thead>
            <th>Image</th>
            <th>Ref</th>
            <th>Designation</th>
            <th>Marque</th>
            <th>Desponibilité</th>
            <th>Ancien Prix</th>
            <th>Date Ancien Prix</th>
            <th>Prix</th>
          </thead>

          {products.length > 0 ? (
            <tbody>
              {products
                .slice(0, fetched)
                .map((product: Product, index: number) => (
                  <tr key={index}>
                    <td>
                      <img src={product.Image} alt={product.Designation} />
                    </td>
                    <td>{product.Ref}</td>
                    <td>
                      <a href={product.Link} target="_blank">
                        {product.Designation}
                      </a>
                    </td>
                    <td>{product.Brand}</td>
                    <td>
                      <span
                        style={
                          product.Stock === "En stock"
                            ? { color: "green" }
                            : { color: "red" }
                        }
                      >
                        {product.Stock}
                      </span>
                    </td>
                    <td>{product.Price}</td>
                    <td>{formattedDate}</td>
                    <td>{product.Price}</td>
                  </tr>
                ))}
            </tbody>
          ) : null}
        </table>

        {products.length === 0 ? (
          <p style={{ textAlign: "center" }}>No products found</p>
        ) : null}

        {products.length > fetched ? (
          <span
            className={styles.handle_more_button}
            onClick={__handleLoadMore}
          >
            Load More
          </span>
        ) : null}
      </div>
    </div>
  );
};

export default Products;
