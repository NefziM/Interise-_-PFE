//src/models/index.ts
export { default as ProductModel } from "./product";
export type { CompetitorRo } from "./competitor";