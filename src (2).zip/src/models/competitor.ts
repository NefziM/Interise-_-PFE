export interface CompetitorRo {
  id: string;
  name: string;
  image: string;
  link: string;
}
