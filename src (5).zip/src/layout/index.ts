//src/layout/index.tsx
import Dashboard from "./dashboard";
export { Dashboard };
export { Login } from "./auth";
